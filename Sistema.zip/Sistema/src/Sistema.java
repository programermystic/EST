
import sistema.carga.inicio;
import sistema.carga.carga;

public class Sistema {

    public static void main(String[] args) {
        carga carga = new carga();
        inicio ini = new inicio();
        carga.cargar();
        ini.inicio();

    }

}
