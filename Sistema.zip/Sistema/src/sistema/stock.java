
package sistema;

//clase que guarda los productos que hay en stock
public class stock {

    private String fecha;
    private Integer cantidad;
    private Producto prod; //Esta mal tengo que hacer alrevez ,poner la cola dentro de la fila producto

    public String getFecha() {
        return fecha;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Producto getProd() {
        return prod;
    }

    public void setProd(Producto prod) {
        this.prod = prod;
    }

    public void mostrar() {

        System.out.print(this.getFecha() + " " + this.getCantidad() + " ");

    }
}
