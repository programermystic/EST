
package sistema.retrirar;


import sistema.busqueda.buscar_id;
import sistema.principal.metodos;
import static sistema.principal.metodos.lista;


public class retirar implements metodos{
    
        public static void retirar(Integer codigo, Integer cantidad)//Si el codigo se encuentra en la cola stock la retira
    {
        buscar_id busca = new buscar_id();
        Integer indice = busca.buscar_id(codigo);
        if (indice != -1) {
            if (lista.get(indice).getStock().getCantidad()<cantidad){
                System.out.println("No hay tanta cantidad disponible!!");
                System.out.println("Desea retirar la cantidad disponible?S/N");
                String op = entrada.next();
                entrada.nextLine();

                while (!op.equals("S") && !op.equals("s") && !op.equals("N") && !op.equals("n")) {
                    System.out.println("No hay tanta cantidad disponible!!");
                    System.out.println("Desea retirar la cantidad disponible? S/N");
                    op = entrada.nextLine();
                }

                if (op.equals("s") || op.equals("S")) {
                    lista.get(indice).getStock().setCantidad(0);
                    System.out.println("se retiraron todos los ele mentos restantes");
                     System.out.println(lista.get(indice).getStock().toString());
                    System.out.println(lista.get(indice).toString());
                    
                }

            } else {
                lista.get(indice).getStock().setCantidad(lista.get(indice).getStock().getCantidad() - cantidad);
                System.out.println("se retiraron " + cantidad + " elementos");
                 System.out.println(lista.get(indice).getStock().toString());
                System.out.println(lista.get(indice).toString());
            }
        } else {
            System.out.println("El producto no Existe!");
        }
    }
}
