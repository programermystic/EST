package sistema.carga;

import sistema.Stock.stock;
import sistema.Producto.Producto;
import com.csvreader.CsvReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Random;
import nodo.arbol;
import sistema.principal.metodos;
import static sistema.principal.metodos.lista;

public class carga implements metodos {

    public static void cargar() //lee el archivo y carga los datos en un Arraylist,luego tambien hace la carga randomica de los productos en una cola(FIFO)
    {
        try {

            CsvReader leerproducto = new CsvReader("C:/Users/diego/Documents/NetBeansProjects/Sistema/archivo/Products.csv");
            leerproducto.readHeaders();

            // Mientras haya lineas obtenemos los datos del archivo
            while (leerproducto.readRecord()) {
                Producto prod = new Producto();
                prod.setId(Integer.parseInt(leerproducto.get(0).trim()));
                prod.setPrices_amoutmax(leerproducto.get(1).trim());
                prod.setPrices_amoutmin(leerproducto.get(2).trim());
                prod.setPrices_avaliability(leerproducto.get(3).trim());
                prod.setPrices_condition(leerproducto.get(4).trim());
                prod.setPrices_currency(leerproducto.get(5).trim());
                prod.setPrices_dateseen(leerproducto.get(6).trim());
                if (leerproducto.get(7).equals("TRUE")) {
                    prod.setPrice_issale(true);
                } else {
                    prod.setPrice_issale(false);
                }
                prod.setPrice_merchant(leerproducto.get(8).trim());
                prod.setPrices_shiping(leerproducto.get(9).trim());
                prod.setPricessourceurls(leerproducto.get(10).trim());
                prod.setAsins(leerproducto.get(11).trim());
                prod.setBrand(leerproducto.get(12).trim());
                prod.setCategories(leerproducto.get(13).trim());
                prod.setDateadded(leerproducto.get(14).trim());
                prod.setDateupdated(leerproducto.get(15).trim());
                prod.setEan(leerproducto.get(16).trim());
                prod.setImagineurls(leerproducto.get(17).trim());
                prod.setKeys(leerproducto.get(18).trim());
                prod.setManufacturer(leerproducto.get(19).trim());
                prod.setManufacturernumber(leerproducto.get(20).trim());
                prod.setName(leerproducto.get(21).trim());
                prod.setPrimarycategories(leerproducto.get(22).trim());
                prod.setSourceurls(leerproducto.get(23).trim());
                prod.setUpc(leerproducto.get(24).trim());
                prod.setWeight(leerproducto.get(25).trim());

                lista.add(prod); // Añade la informacion a la lista
            }

            leerproducto.close(); // Cierra el archivo
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        /*aqui inicia la inicializacion de stock*/
        Integer entradas = generator.nextInt(20);
        for (int i = 0; i < entradas; i++) {
            for (int j = 0; j < lista.size(); j++) {
                java.util.Date data = new Date();
                stock productos = new stock();
                productos.setFecha("" + data);
                stock.setCantidad(generator.nextInt(100));
                lista.get(i).setStock(productos);
            }
        }

        for (int i = 0; i < lista.size(); i++) {
            nuevo.agregarNodo(i);
        }
    }
}
