package sistema.carga;

import sistema.main.menu;
import java.util.ArrayList;
import sistema.principal.metodos;
import static sistema.main.menu.menu;

public class inicio implements metodos {

    public static void inicio() { //muestra las opciones en pantalla
        System.out.println("1 – Buscar produto por código.\n2 – Buscar produto por nome.\n 3 – Retirar Produtos por Código.\n4 – Buscar por produtos em árvore binária\n5 – Buscar por produtos utilizando busca binária\n6-Listar Productos\n7-Salir");
        Integer op = entrada.nextInt();
        entrada.nextLine();
        while (op != 7) {
            menu m = new menu();
            m.menu(op);
            System.out.println("1 – Buscar produto por código.\n2 – Buscar produto por nome.\n 3 – Retirar Produtos por Código.\n4 – Buscar por produtos em árvore binária\n5 – Buscar por produtos utilizando busca binária\n6-Listar Productos\n7-Salir");
            op = entrada.nextInt();
            entrada.nextLine();
        }
    }

}
