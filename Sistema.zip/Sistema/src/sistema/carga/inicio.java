
package sistema.carga;

import sistema.main.menu;
import java.util.ArrayList;
import sistema.principal.metodos;
import static sistema.main.menu.menu;


public class inicio implements metodos{
       public void inicio() { //muestra las opciones en pantalla
        System.out.println("1 – Buscar produto por código.\n2 – Buscar produto por nome.\n 3 – Retirar Produtos por Código.\n4-Listar Productos\n6-Salir");
        Integer op = entrada.nextInt();
        while (op != 6) {
            menu m = new menu();
            m.menu(op);
            System.out.println("1 – Buscar produto por código.\n2 – Buscar produto por nome.\n 3 – Retirar Produtos por Código.\n4-Listar Productos\n6-Salir");
            op = entrada.nextInt();
        }
    }




}
