package sistema.mostrar;

import sistema.principal.metodos;
import static sistema.principal.metodos.lista;

public class mostrar_valor implements metodos {

    /**
     *
     * @param id
     */
    public void mostrar_valor(Integer id) //muestra el valor segun el Id
    {
        if (id == -1) {
            System.out.println("Producto no Encontrado...");
        } else {

            System.out.print(lista.get(id).getStock().retorna());
            System.out.println(lista.get(id).toString());

        }

    }
}
