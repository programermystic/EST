package sistema.mostrar;

import sistema.Producto.Producto;
import java.util.ArrayList;
import sistema.principal.metodos;

public class listar implements metodos {

    public static void listar(ArrayList<Producto> prod) {
        // Recorremos la lista y la mostramos en la pantalla
        prod.forEach((producto) -> {
            System.out.println(producto.toString());
        });

    }
}
