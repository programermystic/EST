package sistema.principal;

import sistema.Producto.Producto;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import nodo.arbol;
import nodo.nodo;

public interface metodos {

    static Scanner entrada = new Scanner(System.in);
    static ArrayList<Producto> lista = new ArrayList<Producto>(); // Lista donde guardaremos los datos del archivo
    static ArrayList<Producto> encontrados_nombre = new ArrayList<Producto>();
    final static Random generator = new Random();
    static arbol nuevo = new arbol();
    static nodo nod = new nodo();

}
