package sistema;

public class Sistema {

    public static void main(String[] args) {
        metodos principal = new metodos();
        principal.cargar();
        principal.inicio();

    }

}
