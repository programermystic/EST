package sistema.Stock;

//clase que guarda los productos que hay en stock
public class stock {

    private static String fecha;
    private static Integer cantidad;

    public String getFecha() {
        return fecha;
    }

    /**
     *
     * @return
     */
    public static Integer getCantidad() {
        return cantidad;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public static void setCantidad(Integer cantidad) {
        stock.cantidad = cantidad;
    }

    public static String retorna() {
        return "stock{" + "fecha=" + fecha + ", cantidad=" + cantidad + '}';
    }

    /**
     *
     * @return
     */
}
