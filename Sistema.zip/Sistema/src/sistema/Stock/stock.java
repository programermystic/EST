
package sistema.Stock;

//clase que guarda los productos que hay en stock
public class stock {

    private String fecha;
    private Integer cantidad;

    public String getFecha() {
        return fecha;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }


    @Override
    public String toString() {
        return "stock{" + "fecha=" + fecha + ", cantidad=" + cantidad + '}';
    }
    
}
