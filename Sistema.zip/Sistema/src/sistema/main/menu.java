
package sistema.main;

import sistema.busqueda.buscar_nombre;
import sistema.busqueda.buscar_id;
import sistema.mostrar.listar;
import sistema.principal.metodos;
import sistema.mostrar.mostrar_valor;
import sistema.retrirar.retirar;



public  class menu implements metodos{
     public static void menu(Integer op) //menu de opciones
    {
        switch (op) {
            case 1: {
                System.out.println("Ingrese el Id del campo a mostrar...");
                Integer valor = entrada.nextInt();
                entrada.nextLine();
                mostrar_valor muestra = new mostrar_valor();
                buscar_id buscar = new buscar_id();
                muestra.mostrar_valor(buscar.buscar_id(valor));
            }
            break;
            case 2: {
                System.out.println("Ingrese el Nombre del campo a mostrar...");
                String valor = entrada.nextLine();
                entrada.nextLine();
                buscar_nombre nombre= new buscar_nombre();
                listar listado =new listar();
                listado.listar(nombre.buscar_nombre(valor));
            }
            break;
            case 3: {

                System.out.println("Ingrese el Codigo del producto a retirar...");
                Integer codigo = entrada.nextInt();
                entrada.nextLine();
                System.out.println("Ingrese la cantidad del producto a retirar...");
                Integer cantidad = entrada.nextInt();
                retirar retira =new retirar();
                retira.retirar(codigo, cantidad);

            }
            break;
            case 4:
            {
                 listar listado =new listar();
                listado.listar(lista);
            }
                break;
            default:
                break;
        }
    }
}
