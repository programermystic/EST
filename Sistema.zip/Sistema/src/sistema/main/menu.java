package sistema.main;

import nodo.nodo;
import sistema.busqueda.buscar_nombre;
import sistema.busqueda.buscar_por_id;
import sistema.busqueda.binaria;
import sistema.mostrar.listar;
import sistema.principal.metodos;
import sistema.mostrar.mostrar_valor;
import sistema.retrirar.retirar;

public class menu implements metodos {

    public static void menu(Integer op) //menu de opciones
    {
        switch (op) {
            case 1: {
                System.out.println("Ingrese el Id del campo a mostrar...");
                Integer valor = entrada.nextInt();
                entrada.nextLine();
                mostrar_valor muestra = new mostrar_valor();
                buscar_por_id buscar = new buscar_por_id();
                muestra.mostrar_valor(buscar.buscar_id(valor));
            }
            break;
            case 2: {
                System.out.println("Ingrese el Nombre del campo a mostrar...");
                String valor = entrada.nextLine();
                entrada.nextLine();
                buscar_nombre nombre = new buscar_nombre();
                listar listado = new listar();
                listado.listar(nombre.buscar_nombre(valor));
            }
            break;
            case 3: {

                System.out.println("Ingrese el Codigo del producto a retirar...");
                Integer codigo = entrada.nextInt();
                entrada.nextLine();
                System.out.println("Ingrese la cantidad del producto a retirar...");
                Integer cantidad = entrada.nextInt();
                entrada.nextLine();
                retirar retira = new retirar();
                retirar.retirar(codigo, cantidad);

            }
            break;
            case 4: {

                System.out.println("Ingrese el Codigo del producto a buscar...");
                Integer codigo = entrada.nextInt();
                entrada.nextLine();
                nodo retorno = new nodo();
                retorno = nuevo.buscar(codigo, nuevo.getRaiz());
                if (retorno != null) {
                    System.out.println(lista.get(retorno.getCodigo() - 1));
                } else {
                    System.out.println("Producto no encontrado...");
                }
            }
            break;
            case 5: {
                System.out.println("Ingrese el Codigo del producto a buscar...");
                Integer codigo = entrada.nextInt();
                entrada.nextLine();
                binaria busqueda = new binaria();
                Integer retorno = busqueda.busqueda_binaria(lista, codigo, 0, lista.size());
                mostrar_valor muestra = new mostrar_valor();
                muestra.mostrar_valor(retorno);

            }
            break;
            case 6: {
                listar listado = new listar();
                listado.listar(lista);
            }
            break;
            default:
                break;
        }
    }
}
