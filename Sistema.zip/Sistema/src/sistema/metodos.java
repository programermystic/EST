
package sistema;

import com.csvreader.CsvReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Random;
import java.util.Scanner;

public class metodos {

    static Scanner entrada = new Scanner(System.in);
    static ArrayList<Producto> lista = new ArrayList<Producto>(); // Lista donde guardaremos los datos del archivo
    static ArrayList<Producto> encontrados_nombre = new ArrayList<Producto>();
    static LinkedList<stock> cola = new LinkedList<stock>();
    private final static Random generator = new Random();

    public static void cargar() //lee el archivo y carga los datos en un Arraylist,luego tambien hace la carga randomica de los productos en una cola(FIFO)
    {
        try {

            CsvReader leerproducto = new CsvReader("C:/Users/diego/Documents/NetBeansProjects/Sistema/archivo/Products.csv");
            leerproducto.readHeaders();

            // Mientras haya lineas obtenemos los datos del archivo
            while (leerproducto.readRecord()) {
                Producto prod = new Producto();
                prod.setId(Integer.parseInt(leerproducto.get(0).trim()));
                prod.setPrices_amoutmax(leerproducto.get(1).trim());
                prod.setPrices_amoutmin(leerproducto.get(2).trim());
                prod.setPrices_avaliability(leerproducto.get(3).trim());
                prod.setPrices_condition(leerproducto.get(4).trim());
                prod.setPrices_currency(leerproducto.get(5).trim());
                prod.setPrices_dateseen(leerproducto.get(6).trim());
                if (leerproducto.get(7).equals("TRUE")) {
                    prod.setPrice_issale(true);
                } else {
                    prod.setPrice_issale(false);
                }
                prod.setPrice_merchant(leerproducto.get(8).trim());
                prod.setPrices_shiping(leerproducto.get(9).trim());
                prod.setPricessourceurls(leerproducto.get(10).trim());
                prod.setAsins(leerproducto.get(11).trim());
                prod.setBrand(leerproducto.get(12).trim());
                prod.setCategories(leerproducto.get(13).trim());
                prod.setDateadded(leerproducto.get(14).trim());
                prod.setDateupdated(leerproducto.get(15).trim());
                prod.setEan(leerproducto.get(16).trim());
                prod.setImagineurls(leerproducto.get(17).trim());
                prod.setKeys(leerproducto.get(18).trim());
                prod.setManufacturer(leerproducto.get(19).trim());
                prod.setManufacturernumber(leerproducto.get(20).trim());
                prod.setName(leerproducto.get(21).trim());
                prod.setPrimarycategories(leerproducto.get(22).trim());
                prod.setSourceurls(leerproducto.get(23).trim());
                prod.setUpc(leerproducto.get(24).trim());
                prod.setWeight(leerproducto.get(25).trim());

                lista.add(prod); // Añade la informacion a la lista
            }

            leerproducto.close(); // Cierra el archivo
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        /*aqui inicia la inicializacion de stock*/
        Integer entradas = generator.nextInt(20);
        for (int i = 0; i < entradas; i++) {
            for (int j = 0; j < lista.size(); j++) {
                java.util.Date data = new Date();
                stock productos = new stock();
                productos.setFecha("" + data);
                productos.setCantidad(generator.nextInt(100));
                productos.setProd(lista.get(j));
                cola.add(productos);
            }
        }

    }

    public static void listar(ArrayList<Producto> prod) {
        // Recorremos la lista y la mostramos en la pantalla
        prod.forEach((producto) -> {
            System.out.println(producto.toString());
        });

    }

    public static void listar_stock() //Liista los elementos de la cola que tiene el stock
    {
        for (int i = 0; i < cola.size(); i++) {
            cola.get(i).mostrar();
             System.out.println(cola.get(i).getProd().toString());
           
        }
    }

    public static Integer buscar_id(Integer id) //busca por Id
    {
        boolean encontrado = false;
        Integer i = 0;
        Integer indice = -1;
        while (i < lista.size() && encontrado != true) {
            if (lista.get(i).getId().equals(id)) {
                indice = i;
                encontrado = true;
            }
            i++;
        }
        if (encontrado == false) {
            indice = -1;
        }
        return indice;
    }

    public static ArrayList<Producto> buscar_nombre(String nombre) //busca por nombre
    {
        Integer i;

        for (i = 0; i < lista.size(); i++) {
            if (lista.get(i).getName().equals(nombre) || lista.get(i).getName().contains(nombre)) {
                encontrados_nombre.add(lista.get(i));

            }
        }

        return encontrados_nombre;
    }

    public static void mostrar_valor(Integer id) //muestra el valor segun el Id
    {
        if (id == -1) {
            System.out.println("Producto no Encontrado...");
        } else {

             System.out.println(lista.get(id).toString());
        }

    }

    public static Integer buscar_stock(Integer codigo) //busca si determinado prodcuto esta en stock(cola) 
    {
        Integer i = 0;
        Integer indice = -1;
        boolean bandera = false;
        while (i < cola.size() && bandera == false) {

            // String cadena =""+cola.get(i).getProd().retorna();
            if (Objects.equals(codigo, cola.get(i).getProd().getId())) {
                System.out.println("entra");
                indice = i;
                bandera = true;
            }
            i++;
        }
        return indice;
    }

    public static void retirar(Integer codigo, Integer cantidad)//Si el codigo se encuentra en la cola stock la retira
    {
        Integer indice = buscar_stock(codigo);
        if (indice != -1) {
            if (cola.get(indice).getCantidad() < cantidad) {
                System.out.println("No hay tanta cantidad disponible!!");
                System.out.println("Desea retirar la cantidad disponible?S/N");
                String op = entrada.next();
                entrada.nextLine();

                while (!op.equals("S") && !op.equals("s") && !op.equals("N") && !op.equals("n")) {
                    System.out.println("No hay tanta cantidad disponible!!");
                    System.out.println("Desea retirar la cantidad disponible? S/N");
                    op = entrada.nextLine();
                }

                if (op.equals("s") || op.equals("S")) {
                    cola.get(indice).setCantidad(0);
                    System.out.println("se retiraron todos los ele mentos restantes");
                    cola.get(indice).mostrar();
                    System.out.println(cola.get(indice).getProd().toString());
                    
                }

            } else {
                cola.get(indice).setCantidad(cola.get(indice).getCantidad() - cantidad);
                System.out.println("se retiraron " + cantidad + " elementos");
                cola.get(indice).mostrar();
                System.out.println(cola.get(indice).getProd().toString());
            }
        } else {
            System.out.println("El producto no Existe!");
        }
    }

    public static void menu(Integer op) //menu de opciones
    {
        switch (op) {
            case 1: {
                System.out.println("Ingrese el Id del campo a mostrar...");
                Integer valor = entrada.nextInt();
                entrada.nextLine();
                mostrar_valor(buscar_id(valor));
            }
            break;
            case 2: {
                System.out.println("Ingrese el Nombre del campo a mostrar...");
                String valor = entrada.nextLine();
                listar(buscar_nombre(valor));
            }
            break;
            case 3: {

                System.out.println("Ingrese el Codigo del producto a retirar...");
                Integer codigo = entrada.nextInt();
                entrada.nextLine();
                System.out.println("Ingrese la cantidad del producto a retirar...");
                Integer cantidad = entrada.nextInt();
                //entrada.nextLine();
                retirar(codigo, cantidad);

            }
            break;
            case 4:
                listar(lista);
                break;
            case 5:
                listar_stock();
                break;
            default:
                break;
        }
    }

    public static void inicio() { //muestra las opciones en pantalla
        System.out.println("1 – Buscar produto por código.\n2 – Buscar produto por nome.\n 3 – Retirar Produtos por Código.\n4-Listar Productos\n5-Listar Productos en Stock\n6-Salir");
        Integer op = entrada.nextInt();
        while (op != 6) {
            menu(op);
            System.out.println("1 – Buscar produto por código.\n2 – Buscar produto por nome.\n 3 – Retirar Produtos por Código.\n4-Listar Productos\n5-Listar Productos en Stock\n6-Salir");
            op = entrada.nextInt();
        }
    }
}
