package sistema.busqueda;

import java.util.ArrayList;
import sistema.Producto.Producto;

public class binaria {

    /**
     *
     * @param prod
     * @param X
     * @param i
     * @param j
     * @return
     */
    public int busqueda_binaria(ArrayList<Producto> prod, Integer X, Integer i, Integer j) {
        int medio;
        if (i > j) {
            return 0;
        }
        medio = (i + j) / 2;
        if (prod.get(medio).getId() < X) {
            return busqueda_binaria(prod, X, medio + 1, j);
        } else if (prod.get(medio).getId() > X) {
            return busqueda_binaria(prod, X, i, medio - 1);
        } else {
            return medio;
        }
    }
}
