
package sistema.busqueda;

import sistema.principal.metodos;
import static sistema.principal.metodos.lista;

public class buscar_id implements metodos{
        public static Integer buscar_id(Integer id) //busca por Id
    {
        boolean encontrado = false;
        Integer i = 0;
        Integer indice = -1;
        while (i < lista.size() && encontrado != true) {
            if (lista.get(i).getId().equals(id)) {
                indice = i;
                encontrado = true;
            }
            i++;
        }
        if (encontrado == false) {
            indice = -1;
        }
        return indice;
    }
}
