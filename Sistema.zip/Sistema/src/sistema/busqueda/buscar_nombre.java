
package sistema.busqueda;

import sistema.Producto.Producto;
import java.util.ArrayList;
import sistema.principal.metodos;
import static sistema.principal.metodos.encontrados_nombre;
import static sistema.principal.metodos.lista;


public  class buscar_nombre implements metodos{

     public  ArrayList<Producto> buscar_nombre(String nombre) //busca por nombre
    {
        Integer i;

        for (i = 0; i < lista.size(); i++) {
            if (lista.get(i).getName().equals(nombre) || lista.get(i).getName().contains(nombre)) {
                encontrados_nombre.add(lista.get(i));

            }
        }

        return encontrados_nombre;
    }
}
