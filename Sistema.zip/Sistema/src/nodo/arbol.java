package nodo;

import static sistema.principal.metodos.lista;

public class arbol {

    nodo raiz;

    public arbol() {
        raiz = null;
    }

    public void agregarNodo(int codigo) {
        nodo nuevo;
        nuevo = new nodo();
        nuevo.setCodigo(codigo);
        nuevo.setLeft(null);
        nuevo.setRigth(null);
        if (raiz == null) {
            raiz = nuevo;
        } else {
            nodo anterior = null, reco;
            reco = raiz;
            while (reco != null) {
                anterior = reco;
                if (codigo < reco.getCodigo()) {
                    reco = reco.getLeft();
                } else {
                    reco = reco.getRigth();
                }
            }
            if (codigo < anterior.getCodigo()) {
                anterior.setLeft(nuevo);
            } else {
                anterior.setRigth(nuevo);
            }
        }
    }

    public nodo buscar(int codigo, nodo nod) {

        if (raiz == null || codigo > lista.size()) {
            return null;
        } else if (nod.getCodigo() == codigo) {
            return nod;
        } else if (nod.getCodigo() < codigo) {
            return buscar(codigo, nod.getRigth());
        } else {
            return buscar(codigo, nod.getLeft());
        }

    }

    public nodo getRaiz() {
        return raiz;
    }
}
