package nodo;

public class nodo {

    private int codigo;
    private nodo rigth;
    private nodo left;

    @Override
    public String toString() {
        return "nodo{" + "codigo=" + codigo + ", rigth=" + rigth + ", left=" + left + '}';
    }

    public int getCodigo() {
        return codigo;
    }

    public nodo getRigth() {
        return rigth;
    }

    public nodo getLeft() {
        return left;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setRigth(nodo rigth) {
        this.rigth = rigth;
    }

    public void setLeft(nodo left) {
        this.left = left;
    }

}
